//
//  HomeViewModel.swift
//  ShopApp
//
//  Created by Tomiris on 23.05.2022.
//

import SwiftUI
import Combine

class HomeViewModel: ObservableObject {
    
    @Published var productType: ProductType = .Brushes
    
    @Published var products: [Product] = [
        Product(type: .Brushes, title: "Watercolor Brush", subtitle: "Blick Masterstroke", price:"$65", productImage: "brush1"),
        Product(type: .Brushes, title: "Acrylyc Brush", subtitle: "Princeton Catalyst", price:"$59.60", productImage: "brush2"),
        Product(type: .Dyes, title: "Oil Paint Set", subtitle: "HWC Studio", price:"$35", productImage: "color"),
        Product(type: .Dyes, title: "Oil Paint", subtitle: "M. Graham Artists' ", price:"$64.40", productImage: "color1"),
        Product(type: .Dyes, title: "Watercolor Paint", subtitle: "Grumbacher Academy ", price:"$76", productImage: "dye"),
        Product(type: .Dyes, title: "Liquid Dye", subtitle: "Rit Liquid Dye", price:"$5.60", productImage: "dye1"),
        Product(type: .Dyes, title: "Acrylic Paint", subtitle: "Liquitex Basics", price:"$73", productImage: "paint"),
        Product(type: .Papers, title: "Cotton Canvas", subtitle: "Blick Economy", price:"$165", productImage: "paper"),
        Product(type: .Papers, title: "Matboard", subtitle: "Crescent Decorative Matboard", price:"$10", productImage: "paper1"),
        Product(type: .Papers, title: "Canvas Panels", subtitle: "Fredrix Can-Tone", price:"$30", productImage: "paper2"),
        Product(type: .Pencils, title: "Watercolor Pencils", subtitle: "Winsor & Newton", price:"$21", productImage: "pencil"),
        Product(type: .Pencils, title: "Micron Pencils", subtitle: "Sakura Pigma Micron", price:"$35", productImage: "pencil1"),
    ]
    
    @Published var filteredProducts: [Product] = []
    
    // More products on the type..
    @Published var showMoreProductsOnType: Bool = false
    
    // Search Data...
    @Published var searchText: String = ""
    @Published var searchActivated: Bool = false
    @Published var searchedProducts: [Product]?
    
    var searchCancellable: AnyCancellable?
    
    init(){
        filterProductByType()
        
        searchCancellable = $searchText.removeDuplicates()
            .debounce(for: 0.5, scheduler: RunLoop.main)
            .sink(receiveValue: { str in
                if str != ""{
                    self.filterProductBySearch()
                }
                else{
                    self.searchedProducts = nil
                }
            })
    }
    
    func filterProductByType(){
        
        // Filtering Product By Product Type...
        DispatchQueue.global(qos: .userInteractive).async {
            
            let results = self.products
            // Since it will require more memory so were using lazy to perform more...
                .lazy
                .filter { product in
                    
                    return product.type == self.productType
                }
            // Limiting result...
                .prefix(4)
            
            DispatchQueue.main.async {
                
                self.filteredProducts = results.compactMap({ product in
                    return product
                })
            }
        }
    }
    
    func filterProductBySearch(){
        
        // Filtering Product By Product Type...
        DispatchQueue.global(qos: .userInteractive).async {
            
            let results = self.products
            // Since it will require more memory so were using lazy to perform more...
                .lazy
                .filter { product in
                    
                    return product.title.lowercased().contains(self.searchText.lowercased())
                }
            
            DispatchQueue.main.async {
                
                self.searchedProducts = results.compactMap({ product in
                    return product
                })
            }
        }
    }
}
