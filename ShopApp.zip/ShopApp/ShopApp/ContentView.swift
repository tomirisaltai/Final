//
//  ContentView.swift
//  ShopApp
//
//  Created by Tomiris on 22.05.2022.
//

import SwiftUI

struct ContentView: View {
    @AppStorage("log_status") var log_Status: Bool = false
    var body: some View {
        Group{
            if log_Status{
                MainPage()
            } else{
                OpeningPage()
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
