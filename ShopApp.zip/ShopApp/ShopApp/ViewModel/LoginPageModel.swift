//
//  LoginPageModel.swift
//  ShopApp
//
//  Created by Tomiris on 23.05.2022.
//

import SwiftUI

class LoginPageModel: ObservableObject {
    @Published var email: String = ""
    @Published var password: String = ""
    @Published var showpassword: Bool = false
    
    @Published var registerUser: Bool = false
    @Published var reEnterPwd: String = ""
    @Published var showreEnterPwd: Bool = false
    
    @AppStorage("log_status") var log_Status: Bool = false
    
    func Login(){
        withAnimation{
            log_Status=true
        }
    }
    func Register(){
        withAnimation{
            log_Status=true
        }        
    }
    func ForgotPassword(){
        
    }
}

