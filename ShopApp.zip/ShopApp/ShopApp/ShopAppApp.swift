//
//  ShopAppApp.swift
//  ShopApp
//
//  Created by Tomiris on 22.05.2022.
//

import SwiftUI

@main
struct ShopAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
