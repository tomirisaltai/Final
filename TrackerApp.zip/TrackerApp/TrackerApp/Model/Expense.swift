//
//  Expense.swift
//  TrackerApp
//
//  Created by Tomiris on 22.05.2022.
//

import SwiftUI

struct Expense: Identifiable,Hashable{
    var id = UUID().uuidString
    var remark: String
    var amount: Double
    var date: Date
    var type: ExpenseType
    var color: String
}

enum ExpenseType: String{
    case income = "Income"
    case expense = "expense"
    case all = "ALL"
}

var sample_expenses: [Expense] = [
    Expense(remark: "Stencils", amount: 99, date: Date(timeIntervalSince1970: 1652987245), type: .expense, color: "Yellow"),
    Expense(remark: "Food", amount: 19, date: Date(timeIntervalSince1970: 1652814445), type: .expense, color: "Red"),
    Expense(remark: "Taxi Cab", amount: 99, date: Date(timeIntervalSince1970: 1652382445), type: .expense, color: "Purple"),
    Expense(remark: "Monthly Gym", amount: 20, date: Date(timeIntervalSince1970: 1652296045), type: .expense, color: "Green"),
    Expense(remark: "Books", amount: 299, date: Date(timeIntervalSince1970: 1652209645), type: .expense, color: "Yellow"),
    Expense(remark: "Medicine", amount: 399, date: Date(timeIntervalSince1970: 1652036845), type: .expense, color: "Green"),
    Expense(remark: "Laptop pieces", amount: 99, date: Date(timeIntervalSince1970: 1651864045), type: .expense, color: "Red"),
    Expense(remark: "Spotify", amount: 5.99, date: Date(timeIntervalSince1970: 1651691245), type: .expense, color: "Red"),
    Expense(remark: "Drinks", amount: 25, date: Date(timeIntervalSince1970: 1651518445), type: .expense, color: "Yellow"),
    Expense(remark: "Markers", amount: 49, date: Date(timeIntervalSince1970: 1651432045), type: .expense, color: "Green"),
]

