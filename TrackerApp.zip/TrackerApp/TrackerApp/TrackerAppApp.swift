//
//  TrackerAppApp.swift
//  TrackerApp
//
//  Created by Tomiris on 22.05.2022.
//

import SwiftUI

@main
struct TrackerAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
