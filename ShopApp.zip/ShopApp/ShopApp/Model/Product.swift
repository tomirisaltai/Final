//
//  Product.swift
//  ShopApp
//
//  Created by Tomiris on 23.05.2022.
//

import SwiftUI


struct Product: Identifiable, Hashable{
    var id = UUID().uuidString
    var type: ProductType
    var title: String
    var subtitle: String
    var description: String = ""
    var price: String
    var productImage: String = ""
    var quantity: Int = 1
}

enum ProductType: String, CaseIterable{
    case Brushes = "Brushes"
    case Dyes = "Dyes"
    case Pencils = "Pencils"
    case Papers = "Papers"
}
