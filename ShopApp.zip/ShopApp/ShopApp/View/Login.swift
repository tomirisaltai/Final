//
//  Login.swift
//  ShopApp
//
//  Created by Tomiris on 23.05.2022.
//

import SwiftUI

struct Login: View {
    @StateObject var loginData: LoginPageModel = LoginPageModel()
    var body: some View {
        VStack {
            Text("Greetings")
                .font(.custom("AvenirNext-Bold", size: 55))
                .frame(maxWidth: .infinity, alignment: .center)
                .frame(height: getRect().height / 3.8)
                .padding()
                .foregroundColor(.white)
                .background(
                    ZStack{
                        LinearGradient(colors: [
                            Color("red"),
                            Color("red")
                                .opacity(0.8),
                            Color("blue")
                        ], startPoint: .top, endPoint: .bottom)
                        .frame(width: 100, height: 100)
                        .clipShape(Circle())
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
                        .padding(.trailing)
                        .offset(y: -25)
                        .ignoresSafeArea()
                        
                        Circle()
                            .strokeBorder(Color.white.opacity(0.3), lineWidth: 3)
                            .frame(width: 30, height: 30)
                            .blur(radius: 3)
                            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomTrailing)
                            .padding(30)
                        Circle()
                            .strokeBorder(Color.white.opacity(0.3), lineWidth: 3)
                            .frame(width: 23, height: 23)
                            .blur(radius: 2)
                            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
                            .padding(.leading,30)
                    }
                )
            
            ScrollView(.vertical, showsIndicators: false){
                
                VStack(spacing:15){
                    Text(loginData.registerUser ? "Register" : "Login")
                        .font(.custom("AvenirNext-Bold", size: 25).bold())
                        .frame(maxWidth: .infinity, alignment: .leading)
                    
                    CutomTextField(icon: "envelope", title: "Email", hint: "type@gmail.com", value: $loginData.email, showpassword: .constant(false))
                        .padding(.top,30)
                    CutomTextField(icon: "lock", title: "Password", hint: "Your Password", value: $loginData.password, showpassword: $loginData.showpassword)
                        .padding(.top,10)
                    
                    if loginData.registerUser{
                        CutomTextField(icon: "lock", title: "Enter Password Again", hint: "Your Password", value: $loginData.password, showpassword: $loginData.showreEnterPwd)
                            .padding(.top,10)
                    }
                    Button {
                        loginData.ForgotPassword()
                        
                    } label:{
                        
                        Text("Reset Password")
                            .font(.custom("AvenirNext", size: 18))
                            .fontWeight(.semibold)
                            .foregroundColor(Color("blue"))
                    }
                    .padding(.top,8)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    
                    Button {
                        if loginData.registerUser{
                            loginData.Register()
                        } else {
                            loginData.Login()
                        }
                    } label :{
                        Text("Login")
                            .font(.custom("AvenirNext-Bold", size: 22))
                            .padding(.vertical,20)
                            .frame(maxWidth: .infinity)
                            .foregroundColor(.white)
                            .background(Color("blue"))
                            .cornerRadius(15)
                            .shadow(color: Color.black.opacity(0.1), radius: 5, x: 5, y: 5)
                    }
                    .padding(.top,25)
                    .padding(.horizontal)
                    
                    Button {
                        withAnimation{
                            loginData.registerUser.toggle()
                        }
                        
                    } label:{
                        
                        Text(loginData.registerUser ? "Back to Login" : "Create Account")
                            .font(.custom("AvenirNext", size: 18))
                            .fontWeight(.semibold)
                            .foregroundColor(Color("blue"))
                    }
                    .padding(.top,8)
                    
                }
                .padding(30)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(
                Color.white
                    .clipShape(CustomCorners(corners: [.topLeft,.topRight], radius: 25))
                    .ignoresSafeArea()
                
            )
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color("blue"))
        
        
    }
    
    @ViewBuilder
    func CutomTextField(icon: String, title: String, hint:String, value: Binding<String>, showpassword: Binding<Bool>)-> some View{
        VStack(alignment: .leading, spacing: 12) {
            Label{
                Text(title)
                    .font(.custom("AvenirNext-Bold", size: 18))
                
            }icon:{
                Image(systemName: icon)
            }
            .foregroundColor(Color.black.opacity(0.8))
            
            if title.contains("Password") && !showpassword.wrappedValue{
                SecureField(hint, text: value)
                    .padding(.top,2)
            } else {
                TextField(hint, text: value)
                    .padding(.top,2)
            }
            
            Divider()
                .background(Color.black.opacity(0.4))
        }
        .overlay(
            Group{
                if title.contains("Password"){
                    Button(action: {
                        showpassword.wrappedValue.toggle()
                    }, label: {
                        Text(showpassword.wrappedValue ? "Hide" : "Show")
                            .font(.custom("AvenirNext-Bold", size: 15))
                            .foregroundColor(Color("blue"))
                    })
                    .offset(y:8)
                }
            }
            ,alignment: .trailing
            
        )
    }
}

struct Login_Previews: PreviewProvider {
    static var previews: some View {
        Login()
    }
}
